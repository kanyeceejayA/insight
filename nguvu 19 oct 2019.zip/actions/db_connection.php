<?php

include 'env.php';

// error_reporting(-1);
// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);

$dbuser =  env('dbuser');
$dbpass = env('dbpass');
$dbname =  env('dbname');
$dbserver = 'localhost';

 $params = array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, 
                 PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC);

$pdo = new PDO('mysql:host=localhost;dbname='.$dbname.';charset=utf8', $dbuser, $dbpass, $params);
$sqlFunctionCallMethod = 'CALL ';

   
// Create connection for mySQli
$connect = new mysqli($dbserver,$dbuser,$dbpass,$dbname);
// Check connection
if (!$connect) {
    die("Connection failed: " . $connect->connect_error);
}
function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data,ENT_QUOTES);
  return $data;
}



?>
