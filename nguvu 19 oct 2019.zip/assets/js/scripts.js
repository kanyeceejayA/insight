function js_search() {
  // Declare variables
  var input, filter, table, tr, td, i, txtValue, field;
  input = document.getElementById("fast_search");
  field="div";
  if (document.getElementById("onlyCompany").checked == true) {field="strong"};
  filter = input.value.toUpperCase();
  table = document.getElementById("cardholder");
  tr = table.getElementsByClassName("card");

  // Loop through all table rows, and hide those who don't match the search query
  for (i = 0; i < tr.length; i++) {
    td = tr[i].getElementsByTagName(field)[0];
    if (td) {
      txtValue = td.textContent || td.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        tr[i].style.display = "";
      } else {
        tr[i].style.display = "none";
      }
    }
  }
}


  function reallySure (event) {
    var message = 'are you sure you want to delete this from the Database? this action is irreversible.';
    action = confirm(message) ? true : event.preventDefault();
}
var aElems = document.getElementsByClassName('myDelete');

for (var i = 0, len = aElems.length; i < len; i++) {
    aElems[i].addEventListener('click', reallySure);
}