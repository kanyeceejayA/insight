<?php 
header("location:list_startups");