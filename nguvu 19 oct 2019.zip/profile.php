<?php 
      if (!isset($_GET['p'])) {
        header('location:startups');
      }
      include 'assets/header.php';
      require ("actions/db_connection.php"); ?>
  <div class="page-header header-filter" data-parallax="true" style="background-image: url('assets/img/bg.jpg');">
    <div class="container">
      <div class="row">
        <div class="col-md-8 ml-auto mr-auto">
          <div class="brand" style="text-align: center;">
            <br/>
            <h1 class="title" style="color: white">Company Profile</h1>
          </div>
        </div>
      </div>
    </div>
  </div>
  <?php
    $stmt = $pdo->prepare('select * from single_startups_view where s_id=?');
    $stmt->execute(array($_GET['p']));
    foreach ($stmt as $row) {
      $logo = $row['logo'];
      $name = $row['name'];
      $type = $row['type'];
      $location = $row['location'];
      $f_year = $row['f_year'];
      //handle money
      $fmt2 = new NumberFormatter( 'UG', NumberFormatter::DECIMAL );
      $fmt2->setAttribute(NumberFormatter::MAX_FRACTION_DIGITS, 0);
      $funding = $fmt2->formatCurrency(($row['funding']),"USD");
      $funding = 'US $'.$funding;
      $status = $row['status'];
      $website = $row['website'];
      $facebook = $row['facebook'];
      $twitter = $row['twitter'];
      $linkedin = $row['linkedin'];

      $type2 = $row['type2'];
      $email = $row['email'];
      $funding_stage = $row['funding_stage'];
      $employees = $row['employees'];
      $founders = $row['founders'];
      $countries = $row['countries'];
      $countries = str_replace(',', ', ', $countries);     
      $description = $row['description'];

    }
  ?>
  <main class="main main-raised">
    <br>
    <div class="container">
      <div class="row">
        <div id="logo" class="col-sm-2" style="align-self: center;">
          <img src="<?php echo $logo;?>" alt="Raised Image" class="img-raised rounded img-fluid">
        </div>
        <div class="col-sm-7">
          <h2 class="title"><?php echo $name;?><br>
          <small><?php echo $location;?></small></h2>
        </div>
        <div class="col-sm-3 card">
          <p class="title">Total Funding Amount<br> <span><?php echo $funding;?></span></p>
        </div>
      </div> <!-- row -->

      <div class="row">
        <div class="col-sm-9">
      <div class="row value">
        <div class="col-sm-2">Categories:</div>
        <div class="col-sm-8"><?php echo $type.', '.$type2;?></div>
      </div> <!-- row of values -->
      <div class="row value">
        <div class="col-sm-2">Founded:</div>
        <div class="col-sm-8"><?php echo $f_year;?></div>
      </div> <!-- row of values -->
      <div class="row value">
        <div class="col-sm-2">Founders:</div>
        <div class="col-sm-8"><?php echo $founders;?></div>
      </div> <!-- row of values -->
      <div class="row value">
        <div class="col-sm-2">Countries:</div>
        <div class="col-sm-8"><?php echo $countries;?></div>
      </div> <!-- row of values -->
      <div class="row value">
        <div class="col-sm-2">Funding Status:</div>
        <div class="col-sm-8"><span class="badge badge-pill badge-success"><?php echo $status;?></span></div>
      </div> <!-- row of values -->
      <div class="row value">
        <div class="col-sm-2">Employees:</div>
        <div class="col-sm-8"><?php echo $employees;?></div>
      </div> <!-- row of values -->
        <h4><strong>Description</strong></h4>
      <div class="row">
        <h4 class="col"><?php echo $description; ?></h4>
      </div>
    </div>
    <div class="card col-sm-3">
      <div class="card-body">
        <?php
          $stmt = $pdo->prepare('select * from single_startups_view where s_id=?');
          $stmt->execute(array($_GET['p']));
          foreach ($stmt as $row) {
            $logo = $row['logo'];
            $name = $row['name'];
            $type = $row['type'];
          }
        ?>
          <span style='font-size:2em;'>
              <a href='<?php echo $facebook;?>' target='_blank' rel='noopener'><i class='fa fa-facebook'></i>&nbsp;</a>
              <a href='<?php echo $twitter;?>' target='_blank' rel='noopener'><i class='fa fa-twitter'></i>&nbsp;</a>
              <a href='<?php echo $website;?>' target='_blank' rel='noopener'><i class='fa fa-globe'></i>&nbsp;</a>
            </span>
        </div>
      </div>

      </div>

      <style type="text/css">
        .value{
          padding-bottom: 1em;
        }
        .value .col-sm-8{
          float: left;
          /*padding-right: 2em; */
        }
        .value .col-sm-2{
          font-weight: bold;
          /*max-width: 100px;*/
        }
      </style>
      
    </div> <!-- container -->
    <br>
  </main>

<?php include 'assets/footer.php'; ?>